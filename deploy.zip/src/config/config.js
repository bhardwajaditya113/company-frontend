const API_BASE_URL = 'http://127.0.0.1:8000/api';
const IMAGE_BASE_URL = 'http://127.0.0.1:8000';

export {API_BASE_URL,IMAGE_BASE_URL};