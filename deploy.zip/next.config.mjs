/** @type {import('next').NextConfig} */
const nextConfig = {
    output: 'standalone', // Optimized for Azure App Service
    images: {
        domains: [
            '127.0.0.1',
            'localhost',
            'infinityloop.online',
            'admin.infinityloop.online'
        ],
        unoptimized: false
    },
    env: {
        NEXT_PUBLIC_API_URL: process.env.NEXT_PUBLIC_API_URL || 'https://admin.infinityloop.online',
    },
    // Enable compression
    compress: true,
    // Production optimizations
    poweredByHeader: false,
    reactStrictMode: true,
};

export default nextConfig;
